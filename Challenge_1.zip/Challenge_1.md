
# Task 1: List vs. NumPy Array

#### Implementation: Find length of my_list


```python
my_list = [62, 53, 69, 84, 83, 80, 98, 74, 70, 92, 68, 71, 54, 87, 85, 88, 63, 61, 66, 99]

# TODO: Get length of a list

def list_length(input_list):
    return len(input_list)
    return None

# Printing the length of the list
print(list_length(my_list))
```

    20
    

#### Implemention: Find min and max of list


```python
import random

my_list = [62, 53, 69, 84, 83, 80, 98, 74, 70, 92, 68, 71, 54, 87, 85, 88, 63, 61, 66, 99]

#TODO: Find min and max of a list
def list_max_min(input_list): 
    
    minNumber = min(input_list)
    maxNumber = max(input_list)
    return [minNumber,maxNumber]

# Printing min and max of random numbers in a list
result = list_max_min(my_list)
print("Minimum number  {}".format(result[0]))
print("Maximum number: {}".format(result[1]))
```

    Minimum number  53
    Maximum number: 99
    

#### Arithmetic and Statistical Operations on lists


```python
# TODO: multiply each element of the list with the given coeff

coeff = 7.231671067280546 # The constant to be multiplied to each element of the list 

res_list = [i * coeff for i in my_list] # List comprehension

res_list = res_list

# Print the result of the multiplication 
print(res_list)

# TODO: take the average of the elements of the list
mean_res_list = sum(res_list)/len(res_list)

mean_res_list = mean_res_list

# Showing the result of taking the average
print(mean_res_list)
```

    [448.3636061713938, 383.2785665658689, 498.9853036423577, 607.4603696515659, 600.2286985842853, 578.5336853824437, 708.7037645934935, 535.1436589787604, 506.21697470963824, 665.3137381898102, 491.7536325750771, 513.4486457769187, 390.5102376331495, 629.1553828534074, 614.6920407188464, 636.387053920688, 455.5952772386744, 441.1319351041133, 477.29029044051606, 715.935435660774]
    544.9064149195891
    

#### Working with NumPy Arrays


```python
# First element is the result of multiplication of the array with the coefficient coeff. 
# This element is a NumPy array.
# Second element is a list with a length of 2 elements with this format: [min_array, max_array]
# For the third element: take the average of the elements in NumPy array stored in the first 
# element. This third element is a float number.

# Import NumPy library necessary for this part 
import numpy as np

my_array = np.array(my_list) # The NumPy array format of the list is obtained

def math_array(input_array):
    coeff = 7.231671067280546 # The constant to be multiplied 
    multiplication_array = my_array * coeff
    Min_Max_array =  multiplication_array.min(),multiplication_array.max()
    Avg_array = multiplication_array.mean()
   
    res = [multiplication_array, Min_Max_array, Avg_array]
    return res 

# Displaying the result of calling the implemented function on my_array
print(math_array(my_array))
```

    [array([448.36360617, 383.27856657, 498.98530364, 607.46036965,
           600.22869858, 578.53368538, 708.70376459, 535.14365898,
           506.21697471, 665.31373819, 491.75363258, 513.44864578,
           390.51023763, 629.15538285, 614.69204072, 636.38705392,
           455.59527724, 441.1319351 , 477.29029044, 715.93543566]), (383.2785665658689, 715.935435660774), 544.9064149195891]
    

#### NumPy Arrays and files


```python
# Change requested by tutor

import pandas as pd
import os
print(os.getcwd())
grades_np = pd.read_csv(r"C:\Users\Ivan Rojas\Documents\GitHub\ds-ml-ai-challenge-ecodavid\data\grades.csv", header = None)

# Print the grades

display (grades_np)

number_of_grades = grades_np.size
# number_of_grades = None # A variable for taking the size of the array

# Display the size of the array
print("The number of grades are: " + str(number_of_grades))
```

    C:\Users\Ivan Rojas\Documents\GitHub\ds-ml-ai-challenge-ecodavid\notebooks
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>79</td>
    </tr>
    <tr>
      <th>1</th>
      <td>121</td>
    </tr>
    <tr>
      <th>2</th>
      <td>175</td>
    </tr>
    <tr>
      <th>3</th>
      <td>186</td>
    </tr>
    <tr>
      <th>4</th>
      <td>176</td>
    </tr>
    <tr>
      <th>5</th>
      <td>172</td>
    </tr>
    <tr>
      <th>6</th>
      <td>55</td>
    </tr>
    <tr>
      <th>7</th>
      <td>167</td>
    </tr>
    <tr>
      <th>8</th>
      <td>83</td>
    </tr>
    <tr>
      <th>9</th>
      <td>74</td>
    </tr>
    <tr>
      <th>10</th>
      <td>70</td>
    </tr>
    <tr>
      <th>11</th>
      <td>170</td>
    </tr>
    <tr>
      <th>12</th>
      <td>120</td>
    </tr>
    <tr>
      <th>13</th>
      <td>199</td>
    </tr>
    <tr>
      <th>14</th>
      <td>185</td>
    </tr>
    <tr>
      <th>15</th>
      <td>182</td>
    </tr>
    <tr>
      <th>16</th>
      <td>87</td>
    </tr>
    <tr>
      <th>17</th>
      <td>173</td>
    </tr>
    <tr>
      <th>18</th>
      <td>53</td>
    </tr>
    <tr>
      <th>19</th>
      <td>148</td>
    </tr>
    <tr>
      <th>20</th>
      <td>169</td>
    </tr>
    <tr>
      <th>21</th>
      <td>68</td>
    </tr>
    <tr>
      <th>22</th>
      <td>134</td>
    </tr>
    <tr>
      <th>23</th>
      <td>85</td>
    </tr>
    <tr>
      <th>24</th>
      <td>113</td>
    </tr>
    <tr>
      <th>25</th>
      <td>88</td>
    </tr>
    <tr>
      <th>26</th>
      <td>60</td>
    </tr>
    <tr>
      <th>27</th>
      <td>112</td>
    </tr>
    <tr>
      <th>28</th>
      <td>107</td>
    </tr>
    <tr>
      <th>29</th>
      <td>108</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>70</th>
      <td>189</td>
    </tr>
    <tr>
      <th>71</th>
      <td>75</td>
    </tr>
    <tr>
      <th>72</th>
      <td>191</td>
    </tr>
    <tr>
      <th>73</th>
      <td>52</td>
    </tr>
    <tr>
      <th>74</th>
      <td>139</td>
    </tr>
    <tr>
      <th>75</th>
      <td>163</td>
    </tr>
    <tr>
      <th>76</th>
      <td>80</td>
    </tr>
    <tr>
      <th>77</th>
      <td>114</td>
    </tr>
    <tr>
      <th>78</th>
      <td>166</td>
    </tr>
    <tr>
      <th>79</th>
      <td>105</td>
    </tr>
    <tr>
      <th>80</th>
      <td>197</td>
    </tr>
    <tr>
      <th>81</th>
      <td>97</td>
    </tr>
    <tr>
      <th>82</th>
      <td>51</td>
    </tr>
    <tr>
      <th>83</th>
      <td>184</td>
    </tr>
    <tr>
      <th>84</th>
      <td>54</td>
    </tr>
    <tr>
      <th>85</th>
      <td>177</td>
    </tr>
    <tr>
      <th>86</th>
      <td>178</td>
    </tr>
    <tr>
      <th>87</th>
      <td>69</td>
    </tr>
    <tr>
      <th>88</th>
      <td>94</td>
    </tr>
    <tr>
      <th>89</th>
      <td>50</td>
    </tr>
    <tr>
      <th>90</th>
      <td>142</td>
    </tr>
    <tr>
      <th>91</th>
      <td>194</td>
    </tr>
    <tr>
      <th>92</th>
      <td>125</td>
    </tr>
    <tr>
      <th>93</th>
      <td>145</td>
    </tr>
    <tr>
      <th>94</th>
      <td>164</td>
    </tr>
    <tr>
      <th>95</th>
      <td>119</td>
    </tr>
    <tr>
      <th>96</th>
      <td>57</td>
    </tr>
    <tr>
      <th>97</th>
      <td>154</td>
    </tr>
    <tr>
      <th>98</th>
      <td>133</td>
    </tr>
    <tr>
      <th>99</th>
      <td>63</td>
    </tr>
  </tbody>
</table>
<p>100 rows × 1 columns</p>
</div>


    The number of grades are: 100
    

#### Boolean Indexing


```python
# TODO: Split the NumPy array 'grades_np' into even and odd parts

grades_np = np.array(grades_np)

even_grades = grades_np[grades_np%2==0] #Select an array with elements divisable by 2 and with
                                        #remaining equal to cero
odd_grades = grades_np[grades_np%2!=0] 
            
even_grades = even_grades
odd_grades = odd_grades

even_grades_size = even_grades.size
odd_grades_size = odd_grades.size

# even_grades_size = even_grades_size
# odd_grades_size = odd_grades_size

# Display the resulted arrays from the splitting process
print("The even grades are: "+ str(even_grades))
print("The odd grades are: "+ str(odd_grades))

# Display the size of the arrays
print("The number of even grades is: " + str(even_grades_size))
print("The number of odd grades is: " + str(odd_grades_size))
```

    The even grades are: [186 176 172  74  70 170 120 182 148  68 134  88  60 112 108 122 152 130
     198  56 146 188  66 156  82 196 136  92 192  64 100 106  52  80 114 166
     184  54 178  94  50 142 194 164 154]
    The odd grades are: [ 79 121 175  55 167  83 199 185  87 173  53 169  85 113 107 195  95 135
      91 155 151 161  93  73 179 183 171  77  89  61  99 187 111 147  65  59
     123 149 189  75 191 139 163 105 197  97  51 177  69 125 145 119  57 133
      63]
    The number of even grades is: 45
    The number of odd grades is: 55
    

#### Arithmetic Operations and Mask Indexing


```python
# TODO: Take the average of the even grades and specify the indexes with the elements larger 
# than the mean

mean_even_grades = even_grades.mean()# The variable for holding the mean value of the even grades
even_grades > mean_even_grades
greater_than_mean_inds = np.nonzero(even_grades > mean_even_grades)

# Display the taken mean
print("The mean value of the even grades is: " + str(mean_even_grades))

greater_than_mean_inds = greater_than_mean_inds # A list of indexes with the values larger than the "mean_even_grades"

# Displaying the indices
print("Indices with the values greater than the mean are: " + str(greater_than_mean_inds))
```

    The mean value of the even grades is: 126.13333333333334
    Indices with the values greater than the mean are: (array([ 0,  1,  2,  5,  7,  8, 10, 16, 17, 18, 20, 21, 23, 25, 26, 28, 35,
           36, 38, 41, 42, 43, 44], dtype=int64),)
    

#### Sorting, Arithmetic and Statistical Operations on NumPy arrays


```python
# Sort the array of odd_grades from the earlier section in an ascending order.
# Do the same for the even_grade with the reverse order. 
# Try to get the median of the odd_grades
# Then calculate the difference of the median and mean of odd_grades.
# Calculate the Standard Deviation of odd_grades.

# TODO: Sort "odd_grades" in an ascending and "even_grades" in a descending order

sorted_odd_grades = np.sort(odd_grades)
sorted_odd_grades = sorted_odd_grades 

reverse_sorted_even_grades = -np.sort(-even_grades)
reverse_sorted_even_grades = reverse_sorted_even_grades

# Printing the sorted arrays:
print(sorted_odd_grades)
print(reverse_sorted_even_grades)

# Variables which hold median, mean and the absolute difference of median and mean
median_odd_grades = np.median(odd_grades)
mean_odd_grades = np.mean(odd_grades)
mean_median_diff = np.abs(median_odd_grades - mean_odd_grades)
std_odd_grades = np.std(odd_grades)

# Display median, mean, difference of them
print("The median of the odd grades is: " + str(median_odd_grades))
print("The mean of the odd grades is: " + str(mean_odd_grades))
print("The difference of median and the mean of the odd grades is: " + str(mean_median_diff))
print("The standard deviation for odd grades is: " + str(std_odd_grades))
```

    [ 51  53  55  57  59  61  63  65  69  73  75  77  79  83  85  87  89  91
      93  95  97  99 105 107 111 113 119 121 123 125 133 135 139 145 147 149
     151 155 161 163 167 169 171 173 175 177 179 183 185 187 189 191 195 197
     199]
    [198 196 194 192 188 186 184 182 178 176 172 170 166 164 156 154 152 148
     146 142 136 134 130 122 120 114 112 108 106 100  94  92  88  82  80  74
      70  68  66  64  60  56  54  52  50]
    The median of the odd grades is: 121.0
    The mean of the odd grades is: 123.54545454545455
    The difference of median and the mean of the odd grades is: 2.5454545454545467
    The standard deviation for odd grades is: 46.25691817813681
    

#### Multi-Dimensional NumPy Arrays


```python
# TODO: Split the "grades_np" into an array with 4 rows, take the mean, median, std of each 
# row. 

splited_grades_np = grades_np.reshape(4,25)

means = np.mean(splited_grades_np, axis = 1)
medians = np.median(splited_grades_np, axis = 1)
stds = np.std(splited_grades_np, axis = 1)

mean_median_diff_ind = np.argmax(abs(means - medians)) 
print(mean_median_diff_ind) # 2 is the index of the row with the largest difference between 
                            # mean and median

# Variables for holding the mean, median, and std
means = means
medians = medians
stds = stds
mean_median_diff_ind = mean_median_diff_ind 
                                           

# Display the taken values
print("mean values: " + str(means))
print("median values: " + str(medians))
print("std values: " + str(stds))

# The NumPy arrays for holding the new splited array with the shape of (4,:), 
# the sorted grades for each row, and the top 3 grades for each row

sorted_splited_grades = np.sort(splited_grades_np)
best_grades = sorted_splited_grades[ :,-3:] # This range contains all rows and selected
                                            # the last 3 columns of the sorted array

# Display the Best score
print(best_grades)
```

    2
    mean values: [129.76 128.   118.08 123.  ]
    median values: [134. 130. 106. 125.]
    std values: [47.95688063 42.7981308  47.38094132 47.81296895]
    [[185 186 199]
     [188 195 198]
     [191 192 196]
     [184 194 197]]
    

# Task 2. Data Visualization


```python
# Visualization
import matplotlib.pyplot as plt
```

#### Bar Plot


```python
# take a look at  xticks. Using this function, you can assign each 2 students for instance a 
# tick.

Student_index = np.arange(len(even_grades))
plt.bar(Student_index, even_grades)
plt.xlabel('Student Index')
plt.ylabel('grade')
plt.title('Student even grades')
plt.xticks(np.arange(1 ,46, step=2))
```




    ([<matplotlib.axis.XTick at 0x924ce10>,
      <matplotlib.axis.XTick at 0x9658198>,
      <matplotlib.axis.XTick at 0x9640e48>,
      <matplotlib.axis.XTick at 0x9700c50>,
      <matplotlib.axis.XTick at 0x9713160>,
      <matplotlib.axis.XTick at 0x97135c0>,
      <matplotlib.axis.XTick at 0x9713a90>,
      <matplotlib.axis.XTick at 0x9713b38>,
      <matplotlib.axis.XTick at 0x9713f60>,
      <matplotlib.axis.XTick at 0x971b4a8>,
      <matplotlib.axis.XTick at 0x971b9b0>,
      <matplotlib.axis.XTick at 0x971beb8>,
      <matplotlib.axis.XTick at 0x9723400>,
      <matplotlib.axis.XTick at 0x9723908>,
      <matplotlib.axis.XTick at 0x9723e10>,
      <matplotlib.axis.XTick at 0x972a358>,
      <matplotlib.axis.XTick at 0x97234a8>,
      <matplotlib.axis.XTick at 0x971b978>,
      <matplotlib.axis.XTick at 0x972a710>,
      <matplotlib.axis.XTick at 0x972ac18>,
      <matplotlib.axis.XTick at 0x9733198>,
      <matplotlib.axis.XTick at 0x9733668>,
      <matplotlib.axis.XTick at 0x9733b70>],
     <a list of 23 Text xticklabel objects>)




![png](output_22_1.png)


#### Histogram


```python
# Generate a histogram of the even_grades with 9 bins on the horizontal axis

plt.hist(even_grades, bins = 9, rwidth = 0.95, color = 'green') 
plt.xlabel('grade bins')
plt.ylabel('num of students')
plt.title('grades histogram')
```




    Text(0.5, 1.0, 'grades histogram')




![png](output_24_1.png)


#### Subplots (Bonus):


```python
class_0 = even_grades[0:8]
class_1 = even_grades[8:16]
x = np.arange(len(class_0))
width = 0.35
fig, ax = plt.subplots()
c0 = ax.bar(x - width/2, class_0, width, color = 'orange', label = 'setA')
c1 = ax.bar(x + width/2, class_1, width, color = 'blue', label = 'setB')
ax.set_xlabel('set - class')
ax.set_ylabel('grade')
ax.set_title('Sample grades in two sets')
ax.legend()
print(class_0)
print(class_1)
```

    [186 176 172  74  70 170 120 182]
    [148  68 134  88  60 112 108 122]
    


![png](output_26_1.png)


# Task 3: Pandas Dataframe

#### Getting Started


```python
import pandas as pd

input_df = pd.read_csv('Ecommerce-Customers.csv')
input_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Email</th>
      <th>Address</th>
      <th>Avatar</th>
      <th>Avg Session Length</th>
      <th>Time on App</th>
      <th>Time on Website</th>
      <th>Length of Membership</th>
      <th>Yearly Amount Spent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mstephenson@fernandez.com</td>
      <td>835 Frank TunnelWrightmouth, MI 82180-9605</td>
      <td>Violet</td>
      <td>34.497268</td>
      <td>12.655651</td>
      <td>39.577668</td>
      <td>4.082621</td>
      <td>587.951054</td>
    </tr>
    <tr>
      <th>1</th>
      <td>hduke@hotmail.com</td>
      <td>4547 Archer CommonDiazchester, CA 06566-8576</td>
      <td>DarkGreen</td>
      <td>31.926272</td>
      <td>11.109461</td>
      <td>37.268959</td>
      <td>2.664034</td>
      <td>392.204933</td>
    </tr>
    <tr>
      <th>2</th>
      <td>pallen@yahoo.com</td>
      <td>24645 Valerie Unions Suite 582Cobbborough, DC ...</td>
      <td>Bisque</td>
      <td>33.000915</td>
      <td>11.330278</td>
      <td>37.110597</td>
      <td>4.104543</td>
      <td>487.547505</td>
    </tr>
    <tr>
      <th>3</th>
      <td>riverarebecca@gmail.com</td>
      <td>1414 David ThroughwayPort Jason, OH 22070-1220</td>
      <td>SaddleBrown</td>
      <td>34.305557</td>
      <td>13.717514</td>
      <td>36.721283</td>
      <td>3.120179</td>
      <td>581.852344</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mstephens@davidson-herman.com</td>
      <td>14023 Rodriguez PassagePort Jacobville, PR 372...</td>
      <td>MediumAquaMarine</td>
      <td>33.330673</td>
      <td>12.795189</td>
      <td>37.536653</td>
      <td>4.446308</td>
      <td>599.406092</td>
    </tr>
  </tbody>
</table>
</div>




```python
# TODO: Get the shape of the input_df

# Variable for holding the shape
input_shape = [None]

input_shape = input_df.shape
print(input_shape)
input_df.dtypes
# Display the name of the columns and the type of the values
```

    (500, 8)
    




    Email                    object
    Address                  object
    Avatar                   object
    Avg Session Length      float64
    Time on App             float64
    Time on Website         float64
    Length of Membership    float64
    Yearly Amount Spent     float64
    dtype: object




```python
# TODO: Display top 5 rows of input_df

input_df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Email</th>
      <th>Address</th>
      <th>Avatar</th>
      <th>Avg Session Length</th>
      <th>Time on App</th>
      <th>Time on Website</th>
      <th>Length of Membership</th>
      <th>Yearly Amount Spent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mstephenson@fernandez.com</td>
      <td>835 Frank TunnelWrightmouth, MI 82180-9605</td>
      <td>Violet</td>
      <td>34.497268</td>
      <td>12.655651</td>
      <td>39.577668</td>
      <td>4.082621</td>
      <td>587.951054</td>
    </tr>
    <tr>
      <th>1</th>
      <td>hduke@hotmail.com</td>
      <td>4547 Archer CommonDiazchester, CA 06566-8576</td>
      <td>DarkGreen</td>
      <td>31.926272</td>
      <td>11.109461</td>
      <td>37.268959</td>
      <td>2.664034</td>
      <td>392.204933</td>
    </tr>
    <tr>
      <th>2</th>
      <td>pallen@yahoo.com</td>
      <td>24645 Valerie Unions Suite 582Cobbborough, DC ...</td>
      <td>Bisque</td>
      <td>33.000915</td>
      <td>11.330278</td>
      <td>37.110597</td>
      <td>4.104543</td>
      <td>487.547505</td>
    </tr>
    <tr>
      <th>3</th>
      <td>riverarebecca@gmail.com</td>
      <td>1414 David ThroughwayPort Jason, OH 22070-1220</td>
      <td>SaddleBrown</td>
      <td>34.305557</td>
      <td>13.717514</td>
      <td>36.721283</td>
      <td>3.120179</td>
      <td>581.852344</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mstephens@davidson-herman.com</td>
      <td>14023 Rodriguez PassagePort Jacobville, PR 372...</td>
      <td>MediumAquaMarine</td>
      <td>33.330673</td>
      <td>12.795189</td>
      <td>37.536653</td>
      <td>4.446308</td>
      <td>599.406092</td>
    </tr>
  </tbody>
</table>
</div>



#### Average Time spent on Website and App


```python
# TODO: Write function the mean and std of app and website column

def df_math():
    app_mean = input_df['Time on App'].mean()
    app_std = input_df['Time on App'].std()
    web_mean = input_df['Time on Website'].mean()
    web_std = input_df['Time on Website'].std()
    res = [[app_mean, app_std], [web_mean, web_std]] # Format: [[app_mean, app_std], [web_mean, web_std]]
    
    return res 

# Display the return value of the function
print(df_math())
```

    [[12.052487937166134, 0.9942156084725423], [37.06044542094859, 1.0104889067564025]]
    

#### Finding max and the max_ID


```python
def max_finder(input_DataFrame):
     
    max_time_app = input_df['Time on App'].max()
    email_app = input_df.loc[input_df['Time on App'].idxmax(),'Email'] 
    max_time_web = input_df['Time on Website'].max()
    email_web = input_df.loc[input_df['Time on Website'].idxmax(),'Email']
     
    return [email_app, max_time_app, email_web, max_time_web] # format explained above
    
result = max_finder(input_df)

# Displaying the result
print("Email address: {}".format(result[0]))
print("Max time spent on the app: {}".format(result[1]))
print("Email address: {}".format(result[2]))
print("Max time spent on the web: {}".format(result[3]))
```

    Email address: kyang@diaz.org
    Max time spent on the app: 15.126994288792467
    Email address: davisrobert@hicks-smith.com
    Max time spent on the web: 40.005181638101895
    

#### Sort and Selection


```python
def best_score_finder(input_DataFrame):# Function for getting the costumers with the best scores
    scr = input_df['Avg Session Length']*input_df['Length of Membership']# new score formula
    input_df['scr']= scr # Assign the score to a new column called 'scr'
    # sort the users based on score value and select the top 5 users with the highest score.
    best_scores = input_df.sort_values('scr', ascending = False).head(5) 
    return best_scores

# Displaying the results of function with input_df as input
best_scores = best_score_finder(input_df) # input_df
display(best_scores)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Email</th>
      <th>Address</th>
      <th>Avatar</th>
      <th>Avg Session Length</th>
      <th>Time on App</th>
      <th>Time on Website</th>
      <th>Length of Membership</th>
      <th>Yearly Amount Spent</th>
      <th>scr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>157</th>
      <td>asilva@yahoo.com</td>
      <td>USNV JohnsonFPO AP 19026</td>
      <td>Wheat</td>
      <td>34.603311</td>
      <td>12.207298</td>
      <td>33.913847</td>
      <td>6.922689</td>
      <td>744.221867</td>
      <td>239.547973</td>
    </tr>
    <tr>
      <th>396</th>
      <td>waltonkaren@gmail.com</td>
      <td>355 Villegas Isle Apt. 070West Jenniferview, N...</td>
      <td>Green</td>
      <td>35.742670</td>
      <td>10.889828</td>
      <td>35.565436</td>
      <td>6.115199</td>
      <td>669.987141</td>
      <td>218.573537</td>
    </tr>
    <tr>
      <th>151</th>
      <td>alicia85@lee.com</td>
      <td>14220 Carla Flat Suite 521Lake Matthew, DE 06183</td>
      <td>DimGray</td>
      <td>32.887105</td>
      <td>12.387184</td>
      <td>37.431159</td>
      <td>6.401229</td>
      <td>684.163431</td>
      <td>210.517883</td>
    </tr>
    <tr>
      <th>50</th>
      <td>william82@gmail.com</td>
      <td>11143 Park SquaresSamanthatown, UT 97073</td>
      <td>SandyBrown</td>
      <td>33.256335</td>
      <td>13.858062</td>
      <td>37.780265</td>
      <td>5.976768</td>
      <td>725.584814</td>
      <td>198.765406</td>
    </tr>
    <tr>
      <th>24</th>
      <td>youngbarbara@yahoo.com</td>
      <td>019 Elliott Tunnel Suite 190Nicholsbury, WV 60...</td>
      <td>Wheat</td>
      <td>34.507551</td>
      <td>12.893670</td>
      <td>37.635756</td>
      <td>5.705154</td>
      <td>700.917092</td>
      <td>196.870892</td>
    </tr>
  </tbody>
</table>
</div>



```python
# Sort input_df using the values in the column "Yearly Amount Spent". Return the top 5 rows. 
# Store the results of the function in a variable called “best_yearly_spent”.

def best_yearly_spent_finder():
    best_yearly_spent = input_df.sort_values('Yearly Amount Spent', ascending = False).head(5)
    return  best_yearly_spent # Return value is of type "panda dataframe" with 5 rows

best_yearly_spent = best_yearly_spent_finder() # input_df 
display(best_yearly_spent)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Email</th>
      <th>Address</th>
      <th>Avatar</th>
      <th>Avg Session Length</th>
      <th>Time on App</th>
      <th>Time on Website</th>
      <th>Length of Membership</th>
      <th>Yearly Amount Spent</th>
      <th>scr</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>65</th>
      <td>kyang@diaz.org</td>
      <td>223 Love Trail Suite 831Port Jeffrey, IN 46849</td>
      <td>OliveDrab</td>
      <td>34.374258</td>
      <td>15.126994</td>
      <td>37.157624</td>
      <td>5.377594</td>
      <td>765.518462</td>
      <td>184.850790</td>
    </tr>
    <tr>
      <th>157</th>
      <td>asilva@yahoo.com</td>
      <td>USNV JohnsonFPO AP 19026</td>
      <td>Wheat</td>
      <td>34.603311</td>
      <td>12.207298</td>
      <td>33.913847</td>
      <td>6.922689</td>
      <td>744.221867</td>
      <td>239.547973</td>
    </tr>
    <tr>
      <th>50</th>
      <td>william82@gmail.com</td>
      <td>11143 Park SquaresSamanthatown, UT 97073</td>
      <td>SandyBrown</td>
      <td>33.256335</td>
      <td>13.858062</td>
      <td>37.780265</td>
      <td>5.976768</td>
      <td>725.584814</td>
      <td>198.765406</td>
    </tr>
    <tr>
      <th>205</th>
      <td>jeffrey54@mcdonald-williams.com</td>
      <td>297 Francis ValleySouth Lindsey, NY 13669-5367</td>
      <td>Gainsboro</td>
      <td>34.967610</td>
      <td>13.919494</td>
      <td>37.952013</td>
      <td>5.066697</td>
      <td>712.396327</td>
      <td>177.170279</td>
    </tr>
    <tr>
      <th>368</th>
      <td>rhonda01@gmail.com</td>
      <td>939 Watson RunStaceyberg, VT 58376-0454</td>
      <td>Orchid</td>
      <td>34.385820</td>
      <td>12.729720</td>
      <td>36.232110</td>
      <td>5.705941</td>
      <td>708.935185</td>
      <td>196.203452</td>
    </tr>
  </tbody>
</table>
</div>


#### Finding Common Elements


```python
# Find the intersection of the two dataframes. We want to find the email addresses 
# of the users that exist in both dataframes.

def comparisor(a,b):
    comparisor = pd.merge(best_scores, best_yearly_spent, on = 'Email', how = 'inner')['Email']

    return comparisor  # a dataframe that contains the rows that exist in both dataframes a,b

comparisor(best_scores, best_yearly_spent)
```




    0       asilva@yahoo.com
    1    william82@gmail.com
    Name: Email, dtype: object



# Task 4. Regression


```python
# Select the numerical features and formed a new dataframe "num_df". In the cell below, try
# to form this dataframe.

# TODO: Selecting the numerical columns of "input_df"

num_df = input_df.select_dtypes(include = ['float64', 'int'])
num_df = [num_df]
# Print the result
display(num_df)
```


    [     Avg Session Length  Time on App  Time on Website  Length of Membership  \
     0             34.497268    12.655651        39.577668              4.082621   
     1             31.926272    11.109461        37.268959              2.664034   
     2             33.000915    11.330278        37.110597              4.104543   
     3             34.305557    13.717514        36.721283              3.120179   
     4             33.330673    12.795189        37.536653              4.446308   
     5             33.871038    12.026925        34.476878              5.493507   
     6             32.021596    11.366348        36.683776              4.685017   
     7             32.739143    12.351959        37.373359              4.434273   
     8             33.987773    13.386235        37.534497              3.273434   
     9             31.936549    11.814128        37.145168              3.202806   
     10            33.992573    13.338975        37.225806              2.482608   
     11            33.879361    11.584783        37.087926              3.713209   
     12            29.532429    10.961298        37.420216              4.046423   
     13            33.190334    12.959226        36.144667              3.918542   
     14            32.387976    13.148726        36.619957              2.494544   
     15            30.737720    12.636606        36.213763              3.357847   
     16            32.125387    11.733862        34.894093              3.136133   
     17            32.338899    12.013195        38.385137              2.420806   
     18            32.187812    14.715388        38.244115              1.516576   
     19            32.617856    13.989593        37.190504              4.064549   
     20            32.912785    11.365492        37.607793              4.599937   
     21            33.503087    12.877984        37.441021              1.559152   
     22            31.531604    13.378563        38.734006              2.245148   
     23            32.903251    11.657576        36.772604              3.919302   
     24            34.507551    12.893670        37.635756              5.705154   
     25            33.029332    11.765813        37.738525              2.721736   
     26            33.541231    12.783892        36.430650              4.648199   
     27            32.335990    13.007819        37.851779              2.996365   
     28            33.110205    11.982045        35.293088              3.923489   
     29            33.105438    11.965020        37.277812              4.742578   
     ..                  ...          ...              ...                   ...   
     470           32.518197    11.509253        36.599289              3.022676   
     471           34.523020    11.405770        36.378271              4.041245   
     472           33.665990    12.263718        38.860234              3.139527   
     473           31.609840    12.710701        36.166463              2.562819   
     474           33.700886    13.471578        37.071643              2.379076   
     475           33.811733    11.186809        36.298893              4.301996   
     476           34.336677    11.246813        38.682584              2.094762   
     477           31.061325    12.357638        36.166042              4.089331   
     478           33.069768    11.764326        36.875026              3.516051   
     479           34.606242    11.761884        38.126520              1.820811   
     480           34.238242    11.550300        35.769330              4.183144   
     481           32.047815    12.482670        35.536025              3.393903   
     482           30.971676    11.731364        36.074551              4.426364   
     483           33.606851    12.214074        37.198428              2.905238   
     484           33.448125    11.903757        36.874544              2.782758   
     485           33.369381    12.222484        36.355235              3.447018   
     486           33.452295    12.005916        36.534096              4.712234   
     487           32.904692    11.913745        36.058648              1.228112   
     488           35.630854    12.125402        38.187764              4.019051   
     489           32.246350    11.305551        37.133127              1.707390   
     490           34.695591    11.608997        37.684877              3.163092   
     491           34.343922    11.693058        36.812934              3.447093   
     492           33.680937    11.201570        37.835448              2.208814   
     493           32.060914    12.625433        35.539142              5.412358   
     494           33.431097    13.350632        37.965972              2.768852   
     495           33.237660    13.566160        36.417985              3.746573   
     496           34.702529    11.695736        37.190268              3.576526   
     497           32.646777    11.499409        38.332576              4.958264   
     498           33.322501    12.391423        36.840086              2.336485   
     499           33.715981    12.418808        35.771016              2.735160   
     
          Yearly Amount Spent         scr  
     0             587.951054  140.839257  
     1             392.204933   85.052680  
     2             487.547505  135.453680  
     3             581.852344  107.039470  
     4             599.406092  148.198446  
     5             637.102448  186.070791  
     6             521.572175  150.021727  
     7             549.904146  145.174312  
     8             570.200409  111.256717  
     9             427.199385  102.286572  
     10            492.606013   84.390225  
     11            522.337405  125.801154  
     12            408.640351  119.500705  
     13            573.415867  130.057713  
     14            470.452733   80.793219  
     15            461.780742  103.212557  
     16            457.847696  100.749477  
     17            407.704548   78.286207  
     18            452.315675   48.815250  
     19            605.061039  132.576860  
     20            534.705744  151.396750  
     21            419.938775   52.236403  
     22            436.515606   70.793112  
     23            519.340989  128.957787  
     24            700.917092  196.870892  
     25            423.179992   89.897122  
     26            619.895640  155.906328  
     27            486.838935   96.890412  
     28            529.537665  129.907517  
     29            554.722084  157.005106  
     ..                   ...         ...  
     470           424.728774   98.291965  
     471           541.049831  139.515979  
     472           469.383146  105.695283  
     473           444.545550   81.010291  
     474           492.556834   80.176985  
     475           535.321610  145.457959  
     476           408.958336   71.927155  
     477           487.555458  127.020035  
     478           487.646232  116.274992  
     479           402.167122   63.011414  
     480           551.023002  143.223485  
     481           497.389558  108.767167  
     482           494.638610  137.091913  
     483           479.247417   97.635912  
     484           462.656519   93.078032  
     485           515.502480  115.024850  
     486           576.477607  157.635029  
     487           357.857984   40.410662  
     488           597.739879  143.202234  
     489           327.377953   55.057087  
     490           510.401388  109.745345  
     491           510.501478  118.386689  
     492           403.819520   74.394914  
     493           627.603319  173.525141  
     494           510.661792   92.565758  
     495           573.847438  124.527319  
     496           529.049004  124.114494  
     497           551.620145  161.871353  
     498           456.469510   77.857513  
     499           497.778642   92.218588  
     
     [500 rows x 6 columns]]



```python
# Develop a linear regression model and return the mean squared error on the test set 

from sklearn.linear_model import LinearRegression
from sklearn import metrics
from sklearn.metrics import mean_squared_error

def predict_model(train_set, test_set):
     
    test_set = pd.read_csv('test.csv')
    train_set = pd.read_csv('train.csv')
    
    y_train = train_set['Yearly Amount Spent']
    y_test = test_set['Yearly Amount Spent']
    
    x_train = train_set[['Avg Session Length', 'Time on App', 'Time on Website', 'Length of Membership']]
    x_test = test_set[['Avg Session Length', 'Time on App', 'Time on Website', 'Length of Membership']]
    
    linreg = LinearRegression()
    linreg.fit(x_train,y_train)
    
    l_model = linreg.predict(x_test)
    
    res = mean_squared_error(y_test, l_model)
    
    return res

err = predict_model(train_set, test_set)

print("The mean square error of the model on the test set is: {}".format(err))
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-25-2f5345f7091e> in <module>
         25     return res
         26 
    ---> 27 err = predict_model(train_set, test_set)
         28 
         29 print("The mean square error of the model on the test set is: {}".format(err))
    

    NameError: name 'train_set' is not defined

